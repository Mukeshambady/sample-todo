/* eslint-disable react/prop-types */
function TaskCard({ name, priority }) {
  return (
    <div className="flex justify-between items-center border rounded shadow-md p-5 ">
      <div>
        <p className="p-2">Task Name : {" " + name + " "}</p>
        <p className="p-1">Priority :{" " + priority + " "}</p>
      </div>
      <div>
        <button className="p-2 bg-red-400 rounded-lg">Delete</button>
      </div>
    </div>
  );
}

export default TaskCard;
