import { useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addTask, setInitialTask } from "../../util/reduxStore/taskSlice";

function AddTask() {
  const taskNameRef = useRef();
  const priorityRef = useRef();
  const dispatch = useDispatch();
  const taskList = useSelector((state) => state.taskList.tasks);

  //   functions
  const handleSubmit = (e) => {
    e.preventDefault();

    console.log(taskNameRef.current.value);
    const data = {
      name: taskNameRef.current.value,
      priority: priorityRef.current.value,
    };
    dispatch(addTask(data));
  };

  useEffect(() => {
    if (taskList?.length) {
      localStorage.setItem("taskList", JSON.stringify(taskList));
    } else {
      const existingList = JSON.parse(localStorage.getItem("taskList"));
      if (existingList?.length) {
        dispatch(setInitialTask(existingList));
      }
    }

    return () => {
      //   second
    };
  }, [taskList]);

  return (
    <div className="w-1/2 border rounded shadow-md m-auto">
      <form
        className="flex flex-col justify-center items-center gap-5 m-5"
        onSubmit={handleSubmit}
      >
        <h1 className="text-3xl font-bold underline">Task Manger</h1>
        <hr />
        <div className="p-5 border max-w-96">
          <div>
            <label htmlFor="task-name">
              Task Name
              <input
                id="task-name"
                ref={taskNameRef}
                type="text"
                className="border border-black m-2 p-2 w-full"
                name="taskName"
                required
              />
            </label>
          </div>
          <div>
            <label htmlFor="priority">
              Priority
              <select
                id="priority"
                className="border border-black m-2 p-2 w-full"
                ref={priorityRef}
                required
              >
                <option value="">Select</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </label>
            <div />
          </div>
          <div className="w-full flex justify-end">
            <button
              type="submit"
              className="bg-green-900 rounded-md p-2 text-white font-bold"
            >
              Add Task
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}

export default AddTask;
