import { createSlice } from "@reduxjs/toolkit";

export const taskSlice = createSlice({
  name: "taskList",
  initialState: {
    tasks: [],
  },
  reducers: {
    addTask: (state, actions) => {
      console.log("🚀 ~ payload:", actions.payload);
      state.tasks.push(actions.payload);
    },
    setInitialTask: (state, actions) => {
      console.log("🚀 ~ payload:", actions.payload);
      state.tasks = actions.payload;
    },
  },
});
export const { addTask, setInitialTask } = taskSlice.actions;
export default taskSlice.reducer;
