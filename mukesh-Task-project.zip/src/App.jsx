import { Provider } from "react-redux";
import AddTask from "./component/add-task/AddTask";
import store from "./util/reduxStore/store";
import TaskCard from "./component/TaskCard";

function App() {
  return (
    <>
      <Provider store={store}>
        <main className="m-5">
          <AddTask />
          <div className="w-1/2  m-auto">
            <TaskCard name={"task-1"} priority={"High"} />
            <TaskCard name={"task-1"} priority={"High"} />
            <TaskCard name={"task-1"} priority={"High"} />
            <TaskCard name={"task-1"} priority={"High"} />
            <TaskCard name={"task-1"} priority={"High"} />
            <TaskCard name={"task-1"} priority={"High"} />
            <TaskCard name={"task-1"} priority={"High"} />
            <TaskCard name={"task-1"} priority={"High"} />
          </div>
        </main>
      </Provider>
    </>
  );
}

export default App;
